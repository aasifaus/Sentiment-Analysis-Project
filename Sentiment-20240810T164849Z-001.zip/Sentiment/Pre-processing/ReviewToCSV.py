import os
import pandas as pd

data_path = 'data'

reviews = []
labels = []

categories = ['dvd', 'books', 'electronics', 'kitchen']

# Loop through each category
for category in categories:
    category_path = os.path.join(data_path, category)
    
    # Read positive reviews
    with open(os.path.join(category_path, 'positive.review'), 'r', encoding='utf-8') as file:
        positive_reviews = file.readlines()
        reviews.extend(positive_reviews)
        labels.extend([1] * len(positive_reviews))  # Label as 1 (positive)
    
    # Read negative reviews
    with open(os.path.join(category_path, 'negative.review'), 'r', encoding='utf-8') as file:
        negative_reviews = file.readlines()
        reviews.extend(negative_reviews)
        labels.extend([0] * len(negative_reviews))  # Label as 0 (negative)

# Create a DataFrame
df = pd.DataFrame({
    'review': reviews,
    'label': labels
})

# Shuffle the DataFrame (optional but recommended)
#df = df.sample(frac=1).reset_index(drop=True)

# Save the DataFrame to a CSV file
df.to_csv('sentiment_reviews.csv', index=False)

print("DataFrame created and saved as sentiment_reviews.csv")
