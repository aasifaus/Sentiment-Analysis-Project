from flask import Flask, render_template, request
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import re

# Load the trained model
model = tf.keras.models.load_model('sentiment_model.h5')

# Tokenizer settings (use the same settings used during training)
tokenizer = tf.keras.preprocessing.text.Tokenizer(num_words=5000)
max_length = 100  # Same as used during training

# Flask app setup
app = Flask(__name__)

# Function to clean and preprocess the text
def clean_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# Route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle form submission
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get the review text from the form
        review = request.form['review']
        
        # Clean and preprocess the review
        cleaned_review = clean_text(review)
        
        # Tokenize and pad the review
        sequence = tokenizer.texts_to_sequences([cleaned_review])
        padded_sequence = pad_sequences(sequence, maxlen=max_length)
        
        # Make the prediction
        prediction = model.predict(padded_sequence)[0][0]
        
        # Determine the sentiment
        sentiment = "Positive" if prediction > 0.5 else "Negative"
        
        return render_template('index.html', prediction_text=f'Sentiment: {sentiment}')

if __name__ == "__main__":
    app.run(debug=True)

